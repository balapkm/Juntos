# Useful links and tools

There are some links and tools which are very useful when developing
using PhpSpreadsheet.

## OpenXML / SpreadsheetML

-   [File format
    documentation](http://www.ecma-international.org/news/TC45_current_work/TC45_available_docs.htm)
-   [OpenXML Explained
    e-book](http://openxmldeveloper.org/articles/1970.aspx)
-   [Microsoft Office Compatibility Pack for Word, Excel, and PowerPoint
    2007 File
    Formats](http://www.microsoft.com/downloads/details.aspx?familyid=941b3470-3ae9-4aee-8f43-c6bb74cd1466&displaylang=en)
-   [OpenXML Package Explorer](http://www.codeplex.com/PackageExplorer/)
